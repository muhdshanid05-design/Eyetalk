from django.apps import AppConfig


class MorsecodeReaderAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'morsecode_reader_app'
