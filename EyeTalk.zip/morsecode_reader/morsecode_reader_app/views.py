from urllib import request
from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from .import models
import json


# Create your views here.
def home(request):
    user=models.Register.objects.get(email=request.session['email'])
    return render(request,'home.html',{'user':user})

def index(request):
    return render(request,'index.html')

def register(request):
    if request.method=='POST':
        fullname=request.POST.get('fullname')
        username=request.POST.get('username')
        remember=request.POST.get('remember')
        confirm_password=request.POST.get('confirm_password')        
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        age=request.POST.get('age')
        email=request.POST.get('email')
        gender=request.POST.get('gender')
        health_condition = request.POST.get('health_condition')
        
        if password==confirm_password:
            if models.Register.objects.filter(email=email).exists():
                return HttpResponse(' user already exists ')
            user = models.Register(fullname=fullname,
                                   gender=gender,
                                   password=password,
                                   confirm_password=confirm_password,
                                   email=email,
                                   health_condition=health_condition,
                                   phone=phone,
                                   age=age)
            user.save()
            return redirect('login')
        return HttpResponse('Passwords do not match ')
    return render(request,'login_register.html', {
        'show_register': True
    })
    
def login(request):
    if request.method=="POST":
        email=request.POST.get("email")
        fullname=request.POST.get("fullname")
        password=request.POST.get("password")
        try:
            user=models.Register.objects.get(email=email)
            if user.password==password:
                request.session["email"]=email
                return redirect('home')
            return HttpResponse('<script>alert("Invalid password");window.location.href="/login/";<script>')
        except models.Register.DoesNotExist: 
            return HttpResponse('<script>alert("Invalid User");window.location.href="/login/";</script>')
    return render(request,'login_register.html', {
        'show_register': False
    })





def logout(request):
    request.session.flush()
    return redirect('index')

def  profile(request):
    if 'email' in request.session:
        email = request.session.get('email')
        user = models.Register.objects.get(email=email)
        return render(request,'profile.html',{'user':user})
    return redirect('login')  

def edit_profile(request):
    if 'email' in request.session:
        email=request.session.get('email')
        user=models.Register.objects.get(email=email)
        if request.method == 'POST':
            user.fullname = request.POST.get('fullname')
            user.username = request.POST.get('username')
            user.age = request.POST.get('age')
            user.gender = request.POST.get('gender')
            user.health_condition = request.POST.get('health_condition')
            user.phone = request.POST.get('phone')
            user.address = request.POST.get('address')
            if 'avatar' in request.FILES:
                user.image= request.FILES.get('avatar')

            user.save()
            return redirect('profile') 
              
        return render(request,'edit_profile.html',{'user':user}) 
    return redirect('login')    

def admin_register(request):
    if request.method=='POST':
        fullname=request.POST.get('fullname')
        username=request.POST.get('username')
        remember=request.POST.get('remember')
        confirm_password=request.POST.get('confirm_password')        
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        age=request.POST.get('age')
        email=request.POST.get('email')
        gender=request.POST.get('gender')
        
        if password==confirm_password:
            if models.Admin_Register.objects.filter(email=email).exists():
                return HttpResponse(' user already exists ')
            user = models.Admin_Register(fullname=fullname,
                                   gender=gender,
                                   password=password,
                                   confirm_password=confirm_password,
                                   email=email,
                                   phone=phone,
                                   age=age)
            user.save()
            return redirect('admin_login')
        return HttpResponse('Passwords do not match ')
    return render(request,'admin_login_register.html', {
        'show_register': True
    })

def admin_login(request):
    if request.method=="POST":
        email=request.POST.get("email")
        fullname=request.POST.get("fullname")
        password=request.POST.get("password")
        try:
            user=models.Admin_Register.objects.get(email=email)
            if user.password==password:
                request.session["email"]=email
                return redirect('adminhome')
            return HttpResponse('<script>alert("Invalid password");window.location.href="/admin_login/";<script>')
        except models.Admin_Register.DoesNotExist: 
            return HttpResponse('<script>alert("Invalid User");window.location.href="/admin_login/";</script>')
    return render(request,'admin_login_register.html', {
        'show_register': False
    })
def  admin_profile(request):
    if 'email' in request.session:
        email = request.session.get('email')
        user = models.Admin_Register.objects.get(email=email)
        return render(request,'admin_profile.html',{'admin':user})
    return redirect('admin_login')  

def admin_edit_profile(request):
    if 'email' in request.session:
        email=request.session.get('email')
        user=models.Admin_Register.objects.get(email=email)
        if request.method == 'POST':
            user.fullname = request.POST.get('fullname')
            user.username = request.POST.get('username')
            user.age = request.POST.get('age')
            user.gender = request.POST.get('gender')
            user.phone = request.POST.get('phone')
            user.address = request.POST.get('address')
            if 'avatar' in request.FILES:
                user.image= request.FILES.get('avatar')

            user.save()
            return redirect('admin_profile') 
              
        return render(request,'admin_edit_profile.html',{'admin':user}) 
    return redirect('admin_login')    













def adminhome(request):
    if 'email' not in request.session:
        return redirect('admin_login')

    # BASIC COUNTS
    total_users = models.Register.objects.count()
    total_guardians = models.guardian_register.objects.count()
    total_feedback = models.Feedback.objects.count()

    # CONNECTION STATUS COUNTS
    connected_count = models.GuardianAccessRequest.objects.filter(
        status='approved'
    ).count()

    pending_requests = models.GuardianAccessRequest.objects.filter(
        status='pending'
    ).count()

    rejected_count = models.GuardianAccessRequest.objects.filter(
        status='rejected'
    ).count()

    context = {
        # top cards
        'total_users': total_users,
        'total_guardians': total_guardians,
        'total_feedback': total_feedback,
        'pending_requests': pending_requests,

        # graph + highlight
        'connected_count': connected_count,
        'rejected_count': rejected_count,
    }

    return render(request, 'adminhome.html', context)

 







def userlist(request):
    users=models.Register.objects.all()
    return render(request,'userlist.html',{'users':users})

def deleteuser(request,id):
    user=models.Register.objects.get(id=id)
    user.delete()
    return redirect(userlist)

def approve_user(request, id):
    user = models.Register.objects.get(id=id)
    user.status = 'approved'
    user.save()
    return redirect('userlist')


def reject_user(request, id):
    user = models.Register.objects.get(id=id)
    user.status = 'rejected'
    user.save()
    return redirect('userlist')

from django.shortcuts import render, redirect
from django.http import HttpResponse
from . import models

def feedbackpage(request):
    feedbacks = models.Feedback.objects.all()

    user = None
    if 'email' in request.session:
        user = models.Register.objects.get(email=request.session['email'])

    if request.method == 'POST':
        username = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        models.Feedback.objects.create(
            username=username,
            email=email,
            message=message
        )

        return redirect('home')   # BEST PRACTICE

    return render(request, 'feedback.html', {
        'feedbacks': feedbacks,
        'user': user
    })

        
def guardian_register(request):
    if request.method=='POST':
        fullname=request.POST.get('fullname')
        username=request.POST.get('username')
        remember=request.POST.get('remember')
        confirm_password=request.POST.get('confirm_password')        
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        age=request.POST.get('age')
        email=request.POST.get('email')
        gender=request.POST.get('gender')
        
        if password==confirm_password:
            if models.guardian_register.objects.filter(email=email).exists():
                return HttpResponse(' user already exists ')
            user = models.guardian_register(fullname=fullname,
                                   gender=gender,
                                   password=password,
                                   confirm_password=confirm_password,
                                   email=email,
                                   phone=phone,
                                   age=age)
            user.save()
            return redirect('guardian_login')
        return HttpResponse('Passwords do not match ')
    return render(request,'guardian_log_reg.html', {
        'show_register': True
    })
    
def guardian_login(request):
    if request.method=="POST":
        email=request.POST.get("email")
        fullname=request.POST.get("fullname")
        password=request.POST.get("password")
        try:
            user=models.guardian_register.objects.get(email=email)
            if user.password==password:
                request.session["email"]=email
                return redirect('guardian_home')
            return HttpResponse('<script>alert("Invalid password");window.location.href="/guardian_login/";<script>')
        except models.guardian_register.DoesNotExist: 
            return HttpResponse('<script>alert("Invalid User");window.location.href="/guardian_login/";</script>')
    return render(request,'guardian_log_reg.html', {
        'show_register': False
    })
      
def guardian_home(request):
    if 'email' not in request.session:
        return redirect('guardian_login')

    # Logged-in guardian
    guardian = models.guardian_register.objects.get(
        email=request.session['email']
    )

    # Guardian approved access requests
    approved_requests = models.GuardianAccessRequest.objects.filter(
        guardian=guardian,
        status='approved'
    )

    # Admin approved users ONLY
    connected_users = models.Register.objects.filter(
        status='approved',
        id__in=approved_requests.values_list('user_id', flat=True)
    )

    # Counts
    connected_count = connected_users.count()
    active_sessions = connected_count   # simple logic (viva safe)

    return render(
        request,
        'guardian_home.html',
        {
            'guardian': guardian,
            'connected_users': connected_users,
            'connected_count': connected_count,
            'active_sessions': active_sessions,
            'monitor_mode': 'Live'
        }
    )

def  guardian_profile(request):
    if 'email' in request.session:
        email = request.session.get('email')
        user = models.guardian_register.objects.get(email=email)
        return render(request,'guardian_profile.html',{'guardian':user})
    return redirect('guardian_login')  

def guardian_edit_profile(request):
    if 'email' in request.session:
        email=request.session.get('email')
        user=models.guardian_register.objects.get(email=email)
        if request.method == 'POST':
            user.fullname = request.POST.get('fullname')
            user.username = request.POST.get('username')
            user.age = request.POST.get('age')
            user.gender = request.POST.get('gender')
            user.phone = request.POST.get('phone')
            user.address = request.POST.get('address')
            if 'avatar' in request.FILES:
                user.image= request.FILES.get('avatar')

            user.save()
            return redirect('guardian_profile') 
              
        return render(request,'guardian_edit_profile.html',{'guardian':user}) 
    return redirect('guardian_login')    




def delete_grd(request,id):
    user=models.guardian_register.objects.get(id=id)
    user.delete()
    return redirect('guardian_list')

def approve_grd(request, id):
    user = models.guardian_register.objects.get(id=id)
    user.status = 'approved'
    user.save()
    return redirect('guardian_list')


def reject_grd(request, id):
    user = models.guardian_register.objects.get(id=id)
    user.status = 'rejected'
    user.save()
    return redirect('guardian_list')

def grd_view_userlist(request):
    # Guardian login check
    if 'email' not in request.session:
        return redirect('guardian_login')

    # Logged-in guardian
    guardian = models.guardian_register.objects.get(
        email=request.session['email']
    )

    # All users
    users = models.Register.objects.all()

    # Build a SIMPLE map: user_id -> status (string)
    status_map = {}
    requests = models.GuardianAccessRequest.objects.filter(
        guardian=guardian
    )

    for req in requests:
        status_map[req.user.id] = req.status

    for user in users:
        user.guardian_status = status_map.get(user.id)

    return render(
        request,
        'grd_view_userlist.html',
        {
            'users': users,
            'status_map': status_map,
        }
    )



def request_user_access(request, user_id):
    if 'email' not in request.session:
        return redirect('guardian_login')

    guardian = models.guardian_register.objects.get(
        email=request.session['email']
    )
    user = models.Register.objects.get(id=user_id)

    if request.method == "POST":
        child_name = request.POST.get('child_name')
        child_dob = request.POST.get('child_dob')
        relation = request.POST.get('relation')
        child_address = request.POST.get('child_address')
        reason = request.POST.get('reason')
        proof_image = request.FILES.get('proof_image')

        models.GuardianAccessRequest.objects.create(
            guardian=guardian,
            user=user,
            child_name=child_name,
            child_dob=child_dob,
            relation=relation,
            child_address=child_address,
            reason=reason,
            proof_image=proof_image,
            status='pending'
        )

        return redirect('grd_view_userlist')

    
    return render(
        request,
        'guardian_child_verify.html',
        {'user': user}
    )


def admin_guardian_list(request):
    # (Optional) admin login check
    if 'email' not in request.session:
        return redirect('admin_login')

    guardians = models.guardian_register.objects.all()

    # Build request info per guardian
    guardian_requests = {}

    requests = models.GuardianAccessRequest.objects.all()

    for req in requests:
        # Only keep latest request per guardian
        guardian_requests[req.guardian_id] = req

    return render(
        request,
        'admin_guardian_list.html',
        {
            'guardians': guardians,
            'guardian_requests': guardian_requests
        }
    )


def admin_verify_guardian_request(request, request_id):
    if 'email' not in request.session:
        return redirect('admin_login')

    # Get the request
    access_request = models.GuardianAccessRequest.objects.get(id=request_id)

    guardian = access_request.guardian
    child = access_request.user

    if request.method == "POST":
        action = request.POST.get('action')

        if action == "approve":
            access_request.status = 'approved'
            access_request.save()

        elif action == "reject":
            access_request.status = 'rejected'
            access_request.save()

        return redirect('guardian_list')

    return render(
        request,
        'admin_verify_guardian_request.html',
        {
            'guardian': guardian,
            'child': child,
            'request': access_request
        }
    )

def guardian_list(request):
    if 'email' not in request.session:
        return redirect('admin_login')

    guardians = models.guardian_register.objects.all()

    approved = models.GuardianAccessRequest.objects.select_related(
        'guardian','user'
    ).filter(status='approved')

    guardian_map={}
    for g in guardians:
        g.connected_users=[]
        guardian_map[g.id]=g

    for r in approved:
        guardian_map[r.guardian_id].connected_users.append(r)

    # verification status
    req_map = {r.guardian_id:r for r in models.GuardianAccessRequest.objects.all()}
    for g in guardians:
        r=req_map.get(g.id)
        g.request_status=r.status if r else None
        g.request_id=r.id if r else None

    return render(request,'guardian_list.html',{'guardians':guardians})









def guardian_disconnect_user(request, req_id):
    if 'email' not in request.session:
        return redirect('admin_login')

    models.GuardianAccessRequest.objects.filter(id=req_id).delete()

    return redirect('guardian_list')









def eyetalk_prog(request):
    return render(request, 'eyetalk_prog.html')



def save_message(request):
    """
    Expects JSON: {"text":"...","device_info": {...}}
    JS should include X-CSRFToken header (cookie-based CSRF).
    """
    try:
        data = json.loads(request.body.decode('utf-8'))
        text = (data.get('text') or '').strip()[:2000]
        if not text:
            return JsonResponse({'status': 'error', 'error': 'empty'}, status=400)
        device_info = data.get('device_info') or {}
        user = None
        if 'email' in request.session:
            try:
                user = models.Register.objects.get(email=request.session['email'])
            except models.Register.DoesNotExist:
                user = None
        msg = Message.objects.create(text=text, device_info=device_info, user=user)
        return JsonResponse({'status': 'ok', 'id': msg.id})
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'error': 'invalid json'}, status=400)
    except Exception as e:
        return JsonResponse({'status': 'error', 'error': str(e)}, status=500)
    
    
    
    
    
    
    
    
    
       
    
    
def user_dashboard(request):
    if 'email' not in request.session:
        return redirect('login')

    user = models.Register.objects.get(email=request.session['email'])
    return render(request,'user_dashboard.html',{'user':user})




def eyetalk_learning(request):
    return render(request,'learning_home.html')

def learning_game(request):
    return render(request,'learning_game.html')













def settings(request):
    if 'email' not in request.session:
        return redirect('login')
    return render(request,'user_settings.html')



def save_settings(request):

    if request.method != "POST":
        return JsonResponse({'status': 'error'}, status=400)

    if 'email' not in request.session:
        return JsonResponse({'status': 'unauthorized'}, status=401)

    user = models.Register.objects.get(email=request.session['email'])

    settings_obj, _ = models.UserSettings.objects.get_or_create(user=user)

    data = json.loads(request.body.decode('utf-8'))

    settings_obj.blink_sensitivity = data.get('ear', 0.22)
    settings_obj.dot_time = data.get('dot', 600)
    settings_obj.pause_time = data.get('gap', 2000)
    settings_obj.head_movement = data.get('headMove', False)
    settings_obj.facial_mouse = data.get('facialMouse', False)

    settings_obj.save()

    return JsonResponse({'status': 'ok'})


def reset_settings(request):

    if request.method != "POST":
        return JsonResponse({'status': 'error'}, status=400)

    if 'email' not in request.session:
        return JsonResponse({'status': 'unauthorized'}, status=401)

    user = models.Register.objects.get(email=request.session['email'])

    settings_obj, _ = models.UserSettings.objects.get_or_create(user=user)

    settings_obj.blink_sensitivity = 0.22
    settings_obj.dot_time = 600
    settings_obj.pause_time = 2000
    settings_obj.head_movement = False
    settings_obj.facial_mouse = False

    settings_obj.save()

    return JsonResponse({'status': 'reset'})


def get_settings(request):
    if 'email' not in request.session:
        return JsonResponse({'status':'unauthorized'}, status=401)

    try:
        user = models.Register.objects.get(email=request.session['email'])
    except models.Register.DoesNotExist:
        return JsonResponse({'status':'invalid_user'}, status=404)
    s, _ = models.UserSettings.objects.get_or_create(user=user)

    return JsonResponse({
        'ear': s.blink_sensitivity,
        'dot': s.dot_time,
        'gap': s.pause_time,
        'headMove': s.head_movement,
        'facialMouse': s.facial_mouse
    })
