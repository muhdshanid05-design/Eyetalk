
  /* ===========================================================
     JS: FULL EYE-TRACKING + MORSE DECODER + SAVE TO DJANGO
     =========================================================== */

  const video = document.getElementById("video");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");
  const calibrateBtn = document.getElementById("calibrateBtn");
  const symbolSeq = document.getElementById("symbolSeq");
  const decodedText = document.getElementById("decodedText");
  const speakBtn = document.getElementById("speakBtn");
  const saveBtn = document.getElementById("saveBtn");
  const clearBtn = document.getElementById("clearBtn");
  const blinkLog = document.getElementById("blinkLog");
  const devlog = document.getElementById("devlog");

  let EAR_THRESH = null;
  let blinkActive = false;
  let blinkStart = 0;
  let lastBlink = 0;

  const DOT_DASH_MS = 300;
  const CHAR_GAP_MS = 1200;
  const LONG_CLEAR_MS = 900;

  const WORD_GAP_MS = 2500;   // ADD
  let lastBlinkTime = 0;     // ADD


  let symbolBuffer = [];
  let charTimer = null;
  let messageText = "";

  // Required for blink classification:
  const LEFT_IDX = [33,160,158,133,153,144];
  const RIGHT_IDX = [263,387,385,362,380,373];

  // Morse decode map
  const MORSE_TABLE = {
    ".-":"A","-...":"B","-.-.":"C","-..":"D",".":"E","..-.":"F",
    "--.":"G","....":"H","..":"I",".---":"J","-.-":"K",".-..":"L",
    "--":"M","-.":"N","---":"O",".--.":"P","--.-":"Q",".-.":"R",
    "...":"S","-":"T","..-":"U","...-":"V",".--":"W","-..-":"X","-.--":"Y","--..":"Z",
    "-----":"0",".----":"1","..---":"2","...--":"3","....-":"4",
    ".....":"5","-....":"6","--...":"7","---..":"8","----.":"9",

      // ADD BELOW YOUR EXISTING MORSE_TABLE
    ".-.-.-":".",
    "--..--":",",
    "..--..":"?",
    ".-..-.":"\"",
    "-.-.--":"!",
    "-..-.":"/",
    ".--.-.":"@"


  };

  function logDev(msg) {
    devlog.textContent = msg + "\n" + devlog.textContent;
  }

  // Camera source selection (ADDED)
  const cameraSelect = document.getElementById("cameraSelect");
  const refreshBtn = document.getElementById("refreshDevices");
  let selectedDeviceId = null;

  /* ---------------------------
     EAR Calculation
     --------------------------- */
  function calcEAR(lm, idx) {
    function dist(a,b) {
      return Math.hypot(a.x - b.x, a.y - b.y);
    }
    const p1 = lm[idx[0]], p2 = lm[idx[1]], p3 = lm[idx[2]],
          p4 = lm[idx[3]], p5 = lm[idx[4]], p6 = lm[idx[5]];

    const vert = dist(p2,p6) + dist(p3,p5);
    const horiz = dist(p1,p4);
    return vert / (2*horiz + 1e-6);
  }

  /* ---------------------------
     Character decoding
     --------------------------- */
  function decodeSymbolBuffer() {
    if(symbolBuffer.length===0) return;

    const seq = symbolBuffer.join("");
    const ch = MORSE_TABLE[seq] || "?";

    messageText += ch;
    decodedText.textContent = messageText;
    symbolSeq.textContent = seq + " → " + ch;

    symbolBuffer = [];
  }

  function scheduleCharBoundary() {
    if(charTimer) clearTimeout(charTimer);
    charTimer = setTimeout(() => decodeSymbolBuffer(), CHAR_GAP_MS);
  }

  /* ---------------------------
     Handle blink classification
     --------------------------- */
  function handleBlink(duration) {

    const now = performance.now();

    if (now - lastBlinkTime > WORD_GAP_MS && messageText.length > 0) {
      messageText += " ";
      decodedText.textContent = messageText;
    }
    lastBlinkTime = now;


    if(duration >= LONG_CLEAR_MS) {
      messageText = "";
      symbolBuffer = [];
      symbolSeq.textContent = "-";
      decodedText.textContent = "";
      blinkLog.textContent = `Clear (${duration}ms)`;
      logDev(`Cleared message (blink ${duration}ms)`);
      return;
    }

    const sym = duration <= DOT_DASH_MS ? "." : "-";
    symbolBuffer.push(sym);
    symbolSeq.textContent = symbolBuffer.join("");
    blinkLog.textContent = `Blink ${duration}ms => ${sym}`;
    logDev(`Registered ${sym} for ${duration}ms`);
    scheduleCharBoundary();
  }

  /* ---------------------------
     MAIN FACE MESH / TRACKING
     --------------------------- */
  let faceMesh = null;
  let camera = null; // moved to top-level so stop can access it

  function initFaceMesh() {
    faceMesh = new FaceMesh({
      locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
    });

    faceMesh.setOptions({
      maxNumFaces: 1,
      refineLandmarks: true,
      minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5
    });

    faceMesh.onResults(onResults);
  }

  function onResults(results) {
    if(!results.multiFaceLandmarks || !results.multiFaceLandmarks[0]) {
      return;
    }

    const lm = results.multiFaceLandmarks[0];

    const leftEAR = calcEAR(lm, LEFT_IDX);
    const rightEAR = calcEAR(lm, RIGHT_IDX);
    const ear = (leftEAR + rightEAR) / 2;

    if(EAR_THRESH !== null) {
      const now = performance.now();

      if(ear < EAR_THRESH && !blinkActive) {
        blinkActive = true;
        blinkStart = now;
      }

      if(ear >= EAR_THRESH && blinkActive) {
        blinkActive = false;
        const duration = Math.round(now - blinkStart);
        handleBlink(duration);
      }
    }
  }

  /* ---------------------------
     Camera start / stop
     --------------------------- */

  function startCamera() {
    if(!faceMesh) initFaceMesh();

    camera = new Camera(video, {

      deviceId: selectedDeviceId,
      onFrame: async () => {
        await faceMesh.send({image: video});
      },
      width: 400,
      height: 300
    });


    camera.start();
    startBtn.disabled = true;
    stopBtn.disabled = false;
    logDev("Camera started");
  }

  function stopCamera() {
    try {
      if(camera && camera.stop) camera.stop();
      startBtn.disabled = false;
      stopBtn.disabled = true;
      logDev("Camera stopped");
    } catch (err) {
      logDev("Error stopping camera: " + err);
    }
  }

  // Initialize camera list on page load (ADDED)
  loadCameraDevices();

  /* ---------------------------
     Calibration
     --------------------------- */
  async function calibrate() {
    alert("Calibration: Look at the camera for 3 seconds with eyes OPEN.");

    // Simple default calibration for now
    EAR_THRESH = 0.20;

    alert("Calibration Complete.\nDetected EAR threshold ~ 0.20");
    logDev("Calibration set EAR_THRESH = " + EAR_THRESH);
  }

  /* ---------------------------
     Saving to Django
     --------------------------- */
  function getCookie(name) {
    let cookieValue = null;
    if(document.cookie) {
      const cookies = document.cookie.split(';');
      for(let c of cookies) {
        c = c.trim();
        if(c.startsWith(name + '=')) {
          cookieValue = decodeURIComponent(c.split('=')[1]);
        }
      }
    }
    return cookieValue;
  }

  async function saveToServer() {
    if(!messageText.trim()) {
      alert("No message to save!");
      return;
    }

    const response = await fetch("{% url 'eyetalk_save' %}", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCookie("csrftoken")
      },
      body: JSON.stringify({
        text: messageText,
        device_info: {
          browser: navigator.userAgent,
          width: window.innerWidth,
          height: window.innerHeight
        }
      })
    });

    const data = await response.json();
    if(data.status === "ok") {
      alert("Message saved!");
      location.reload();
    } else {
      alert("Error: " + data.error);
    }
  }

  /* ---------------------------
     UI EVENTS
     --------------------------- */
  startBtn.onclick = startCamera;
  stopBtn.onclick = stopCamera;
  calibrateBtn.onclick = calibrate;

  speakBtn.onclick = () => {
    const msg = new SpeechSynthesisUtterance(messageText);
    speechSynthesis.speak(msg);
  };

  clearBtn.onclick = () => {
    messageText = "";
    symbolBuffer = [];
    symbolSeq.textContent = "-";
    decodedText.textContent = "";
  };

  saveBtn.onclick = saveToServer;

  document.getElementById('deleteBtn').onclick = () => {
    messageText = messageText.slice(0, -1);
    decodedText.textContent = messageText;
  };


  // Detect available camera devices (ADDED)
  async function loadCameraDevices() {
    cameraSelect.innerHTML = "";

    const devices = await navigator.mediaDevices.enumerateDevices();
    const cams = devices.filter(d => d.kind === "videoinput");

    cams.forEach((cam, i) => {
      const opt = document.createElement("option");
      opt.value = cam.deviceId;
      opt.text = cam.label || `Camera ${i + 1}`;
      cameraSelect.appendChild(opt);
    });

    if (cams.length > 0) {
      selectedDeviceId = cams[0].deviceId; // default laptop cam
    }
  }

  cameraSelect.onchange = () => {
    selectedDeviceId = cameraSelect.value;
  };

  refreshBtn.onclick = loadCameraDevices;


