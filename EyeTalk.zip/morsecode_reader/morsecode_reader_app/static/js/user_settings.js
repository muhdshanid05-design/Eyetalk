const ear=document.getElementById("ear");
const dot=document.getElementById("dot");
const gap=document.getElementById("gap");

const earVal=document.getElementById("earVal");
const dotVal=document.getElementById("dotVal");
const gapVal=document.getElementById("gapVal");

const headMove=document.getElementById("headMove");
const facialMouse=document.getElementById("facialMouse");


fetch('/api/get-settings/')
  .then(r=>r.json())
  .then(d=>{
    ear.value=d.ear;
    dot.value=d.dot;
    gap.value=d.gap;
    headMove.checked=d.headMove;
    facialMouse.checked=d.facialMouse;

    earVal.innerText=d.ear;
    dotVal.innerText=d.dot;
    gapVal.innerText=d.gap;
  });





earVal.innerText=ear.value;
dotVal.innerText=dot.value;
gapVal.innerText=gap.value;

ear.oninput=()=>earVal.innerText=ear.value;
dot.oninput=()=>dotVal.innerText=dot.value;
gap.oninput=()=>gapVal.innerText=gap.value;










function getCookie(name){
  let cookieValue = null;
  if(document.cookie){
    const cookies = document.cookie.split(';');
    for(let c of cookies){
      c = c.trim();
      if(c.startsWith(name + '=')){
        cookieValue = decodeURIComponent(c.split('=')[1]);
      }
    }
  }
  return cookieValue;
}


function saveSettings(){

  fetch('/api/save-settings/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCookie('csrftoken')
    },
    body: JSON.stringify({
      ear: parseFloat(ear.value),
      dot: parseInt(dot.value),
      gap: parseInt(gap.value),
      headMove: headMove.checked,
      facialMouse: facialMouse.checked
    })
  })
  .then(res => res.json())
  .then(data => {
    if(data.status === 'ok'){
      alert('Settings saved to database');
    }
  });
}


function resetSettings(){

  fetch('/api/reset-settings/', {
    method: 'POST',
    headers: {
      'X-CSRFToken': getCookie('csrftoken')
    }
  })
  .then(res => res.json())
  .then(data => {
    if(data.status === 'reset'){
      ear.value = 0.22;
      dot.value = 600;
      gap.value = 2000;
      headMove.checked = false;
      facialMouse.checked = false;

      earVal.innerText = 0.22;
      dotVal.innerText = 600;
      gapVal.innerText = 2000;

      alert('Settings reset');
    }
  });
}
