/* =========================================================
   USER DASHBOARD – EYE + MORSE + MOUSE (FINAL VERSION)
   ========================================================= */

/* ---------------- SETTINGS SYNC ---------------- */

// From user_settings.html (localStorage)
const EAR_THRESHOLD = parseFloat(localStorage.getItem("EAR")) || 0.22;
const DOT_MAX = parseInt(localStorage.getItem("DOT")) || 600;
const COMMAND_GAP = parseInt(localStorage.getItem("GAP")) || 2000;

/* ---------------- DASHBOARD ELEMENTS ---------------- */

const video = document.getElementById("video");
const cards = document.querySelectorAll(".card");

const cameraSelect = document.getElementById("cameraSelect");

let currentCamera = null;
let selectedDeviceId = null;




let currentIndex = 0;
let morseBuffer = "";
let lastBlinkTime = 0;

/* ---------------- TEXT TO SPEECH ---------------- */

let audioUnlocked = false;


async function loadCameras() {
  // 🔑 STEP 1: force permission
  await navigator.mediaDevices.getUserMedia({ video: true });

  // 🔑 STEP 2: now enumerate devices
  const devices = await navigator.mediaDevices.enumerateDevices();
  const cams = devices.filter(d => d.kind === "videoinput");

  cameraSelect.innerHTML = "";

  cams.forEach((cam, i) => {
    const opt = document.createElement("option");
    opt.value = cam.deviceId;
    opt.text = cam.label || `Camera ${i + 1}`;
    cameraSelect.appendChild(opt);
  });

  // default = integrated laptop camera
  if (cams.length > 0) {
    selectedDeviceId = cams[0].deviceId;
    cameraSelect.value = selectedDeviceId;
  }
}




cameraSelect.onchange = () => {
  selectedDeviceId = cameraSelect.value;
  startCamera();
};












function unlockAudio() {
  if (audioUnlocked) return;
  const msg = new SpeechSynthesisUtterance("Audio enabled");
  speechSynthesis.speak(msg);
  audioUnlocked = true;
}

document.addEventListener("click", unlockAudio, { once: true });
document.addEventListener("keydown", unlockAudio, { once: true });




function speak(text) {
  if (!window.speechSynthesis) return;
  speechSynthesis.cancel();
  const msg = new SpeechSynthesisUtterance(text);
  msg.rate = 0.9;
  speechSynthesis.speak(msg);
}

/* ---------------- POPUP SYSTEM ---------------- */

function popup(id, text, bg = "#2563eb") {
  let box = document.getElementById(id);
  if (!box) {
    box = document.createElement("div");
    box.id = id;
    box.style.position = "fixed";
    box.style.right = "20px";
    box.style.padding = "10px 16px";
    box.style.borderRadius = "10px";
    box.style.color = "#fff";
    box.style.fontSize = "14px";
    box.style.zIndex = "9999";
    box.style.boxShadow = "0 8px 20px rgba(0,0,0,.4)";
    document.body.appendChild(box);
  }
  box.style.bottom = id === "camPopup" ? "90px" : "20px";
  box.style.background = bg;
  box.innerText = text;
  box.style.opacity = "1";
}

/* ---------------- CARD HIGHLIGHT ---------------- */

function highlightCard(index) {
  cards.forEach((c, i) => {
    c.style.border =
      i === index ? "2px solid #66f0ff" : "1px solid rgba(255,255,255,0.1)";
    c.style.transform = i === index ? "scale(1.08)" : "scale(1)";
  });

  const name = cards[index].querySelector("h3").innerText;
  popup("actionPopup", `🟦 Selected: ${name}`);
  speak(name + " selected");
}

function nextCard() {
  currentIndex = (currentIndex + 1) % cards.length;
  highlightCard(currentIndex);
}

function prevCard() {
  currentIndex = (currentIndex - 1 + cards.length) % cards.length;
  highlightCard(currentIndex);
}

function openCard() {
  const name = cards[currentIndex].querySelector("h3").innerText;
  popup("actionPopup", `✅ Opening ${name}`, "#16a34a");
  speak("Opening " + name);
  cards[currentIndex].click();
}

/* ---------------- MORSE HANDLING ---------------- */

function registerSymbol(sym) {
  morseBuffer += sym;
  lastBlinkTime = Date.now();
  popup("actionPopup", `Morse: ${morseBuffer}`);
}

setInterval(() => {
  if (!morseBuffer) return;
  if (Date.now() - lastBlinkTime > COMMAND_GAP) {
    if (morseBuffer === ".") nextCard();
    else if (morseBuffer === "..") prevCard();
    else if (morseBuffer === "-") openCard();
    morseBuffer = "";
  }
}, 200);

/* ---------------- EYEBLINK DETECTION ---------------- */

const LEFT_EYE = [33,160,158,133,153,144];
const RIGHT_EYE = [263,387,385,362,380,373];

let blinkActive = false;
let blinkStart = 0;

function ear(lm, idx) {
  const d = (a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  const p = idx.map(i=>lm[i]);
  return (d(p[1],p[5])+d(p[2],p[4]))/(2*d(p[0],p[3])+1e-6);
}

const faceMesh = new FaceMesh({
  locateFile: f => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${f}`
});

faceMesh.setOptions({
  maxNumFaces:1,
  refineLandmarks:true,
  minDetectionConfidence:0.5,
  minTrackingConfidence:0.5
});

faceMesh.onResults(res => {
  if (!res.multiFaceLandmarks) {
    popup("camPopup","❌ Face not detected","#dc2626");
    return;
  }

  popup("camPopup","📷 Camera detected","#16a34a");

  const lm = res.multiFaceLandmarks[0];
  const v = (ear(lm,LEFT_EYE)+ear(lm,RIGHT_EYE))/2;
  const now = performance.now();

  if (v < EAR_THRESHOLD && !blinkActive) {
    blinkActive = true;
    blinkStart = now;
  }

  if (v >= EAR_THRESHOLD && blinkActive) {
    blinkActive = false;
    const dur = Math.round(now - blinkStart);
    if (dur < DOT_MAX) {
      registerSymbol(".");
    } else if (dur >= DOT_MAX) {
      registerSymbol("-");
    }

  }
});

/* ---------------- CAMERA START ---------------- */


async function startCamera() {
  if (currentCamera) {
    currentCamera.stop();
  }

  currentCamera = new Camera(video, {
    deviceId: selectedDeviceId,
    onFrame: async () => {
      await faceMesh.send({ image: video });
    },
    width: 320,
    height: 240
  });

  currentCamera.start();
}


/* ---------------- INIT ---------------- */

window.onload = async () => {
  highlightCard(currentIndex);
  speak("Dashboard ready");

  await loadCameras();   // 👈 camera list load
  startCamera();         // 👈 default (laptop) camera start
};

