from django.db import models

# Create your models here.
class Register(models.Model):
    username=models.TextField(null=True, blank=True,default="no user name added")
    fullname=models.CharField(max_length=100, null=True, blank=True)
    age=models.IntegerField(null=True, blank=True)
    address=models.TextField(null=True, blank=True,default="no address added")
    phone=models. IntegerField(null=True, blank=True)
    email=models.EmailField(unique=True)
    password=models.CharField(max_length=50, null=True, blank=True)
    confirm_password=models.CharField(max_length=50, null=True, blank=True)
    image=models.FileField(upload_to="images/", null=True, blank=True)
    GENDER_CHOICES=[
        ('M','Male'),
        ('F','Female'),
        ('O','Other'),
    ]                       
    gender=models.CharField(max_length=1,choices=GENDER_CHOICES,null=True,blank=True)

    HEALTH_CONDITION_CHOICES = [
    ('paraplegia', 'Paraplegia'),
    ('quadriplegia', 'Quadriplegia'),
    ('hemiplegia', 'Hemiplegia'),
    ('partial', 'Partial Paralysis'),
    ('temporary', 'Temporary Paralysis'),
    ('other', 'Other'),
    ]
    health_condition = models.CharField(max_length=30,choices=HEALTH_CONDITION_CHOICES,null=True,blank=True)

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')

    
class Admin_Register(models.Model):
    username=models.TextField(null=True, blank=True,default="no user name added")
    fullname=models.CharField(max_length=100, null=True, blank=True)
    age=models.IntegerField(null=True, blank=True)
    address=models.TextField(null=True, blank=True,default="no address added")
    phone=models. IntegerField(null=True, blank=True)
    email=models.EmailField(unique=True)
    password=models.CharField(max_length=50, null=True, blank=True)
    confirm_password=models.CharField(max_length=50, null=True, blank=True)
    image=models.FileField(upload_to="images/", null=True, blank=True)
    GENDER_CHOICES=[
        ('M','Male'),
        ('F','Female'),
        ('O','Other'),
    ]                       
    gender=models.CharField(max_length=1,choices=GENDER_CHOICES,null=True,blank=True)

class Feedback(models.Model):
    username=models.TextField(null=True, blank=True,)
    email=models.EmailField(null=True)
    message=models.TextField(null=True, blank=True,default="no address added")
    created_at=models.DateTimeField(auto_now_add=True,null=True)

class guardian_register(models.Model):
    username=models.TextField(null=True, blank=True,default="no user name added")
    fullname=models.CharField(max_length=100, null=True, blank=True)
    age=models.IntegerField(null=True, blank=True)
    address=models.TextField(null=True, blank=True,default="no address added")
    phone=models. IntegerField(null=True, blank=True)
    email=models.EmailField(unique=True)
    password=models.CharField(max_length=50, null=True, blank=True)
    confirm_password=models.CharField(max_length=50, null=True, blank=True)
    image=models.FileField(upload_to="images/", null=True, blank=True)
    GENDER_CHOICES=[
        ('M','Male'),
        ('F','Female'),
        ('O','Other'),
    ]                       
    gender=models.CharField(max_length=1,choices=GENDER_CHOICES,null=True,blank=True)
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')


class GuardianAccessRequest(models.Model):

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    guardian = models.ForeignKey(guardian_register, on_delete=models.CASCADE)
    user = models.ForeignKey(Register, on_delete=models.CASCADE)

    child_name = models.CharField(max_length=100, null=True, blank=True)
    child_dob = models.DateField(null=True, blank=True)
    relation = models.CharField(max_length=50, null=True, blank=True)

    child_address = models.TextField(null=True, blank=True)
    reason = models.TextField(null=True, blank=True)
    proof_image = models.ImageField(upload_to='guardian_proofs/', null=True, blank=True)

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='pending'
    )

    created_at = models.DateTimeField(auto_now_add=True)











class UserSettings(models.Model):
    user = models.OneToOneField(
        Register,
        on_delete=models.CASCADE,
        related_name="settings"
    )

    blink_sensitivity = models.FloatField(default=0.22)   # EAR
    dot_time = models.IntegerField(default=600)
    pause_time = models.IntegerField(default=2000)

    head_movement = models.BooleanField(default=False)
    facial_mouse = models.BooleanField(default=False)

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Settings of {self.user.email}"
